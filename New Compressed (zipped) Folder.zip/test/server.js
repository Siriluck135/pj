const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const path = require('path');
const moment = require('moment-timezone');


const app = express();
app.use(express.json()); // ใช้สำหรับการอ่าน JSON body

// ตั้งค่าการเชื่อมต่อ PostgreSQL
const pool = new Pool({
    user: 'postgres', // ชื่อผู้ใช้ PostgreSQL 
    host: 'localhost',
    database: 'my_database', // ชื่อฐานข้อมูล
    password: '123456', // รหัสผ่าน PostgreSQL 
    port: 5432,
});

// ตั้งค่า middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// หน้าแรก 
app.get('/', (req, res) => {
    res.render('welcome');
});

// section1
app.get('/check-attendance', (req, res) => {
    res.render('index');
});

// section
app.get('/section2', (req, res) => {
    res.render('section2');
});

// เช็คชื่อและบันทึกข้อมูล
app.post('/', async (req, res) => {
    const { studentValue, sectionValue, statusValue, DateNow } = req.body; // ดึงค่าจาก request body

    console.log("Student ID:", studentValue);
    console.log("Section ID:", sectionValue);
    console.log("Status:", statusValue);

    const activeDate = moment().tz("Asia/Bangkok").format('YYYY-MM-DD');

    try {
        // ตรวจสอบว่านักเรียนมีอยู่ในตาราง student หรือไม่
        const studentResult = await pool.query(`SELECT * FROM student WHERE id = $1`, [studentValue]);

        // ถ้านักเรียนไม่มีในตาราง ให้แจ้งเตือน
        if (studentResult.rowCount === 0) {
            res.render('index', { errorMessage: 'รหัสนักเรียนไม่ถูกต้อง!', message: undefined });
            return;
        }
        console.log('นักเรียนพบในระบบ');

        // บันทึกข้อมูลลงในฐานข้อมูล
        const respond = await pool.query(`
            INSERT INTO student_list (student_id, section_id, status, active_date)
            VALUES ($1, $2, $3, $4) RETURNING *;
        `, [studentValue, sectionValue, statusValue, activeDate]);
        

        // ส่งข้อความสำเร็จกลับไปยังหน้า index
        console.log(respond.rows);
        res.send(respond.rows);

    } catch (error) {
        console.log(error);
        res.send(error); // หรือใช้ res.render เพื่อแสดงข้อผิดพลาดในหน้า index
    }
});

// หน้าแสดงรายชื่อนักเรียนที่เช็คชื่อแล้ว
app.get('/student_list', async (req, res) => {
    const { searchId, searchDate } = req.query;

    let query = `
    SELECT student_list.student_id, student_list.section_id, 
           student_list.active_date AS active_date,  
           student_list.status,
           student.first_name, student.last_name, curriculum.short_name_en
    FROM student_list
    JOIN student ON student_list.student_id = student.id
    JOIN curriculum ON student.curriculum_id = curriculum.id
    `;
    const values = [];
    let conditions = [];

    // ถ้ามีการค้นหารหัสนักเรียน
    if (searchId && searchId.trim() !== '') {
        conditions.push('student_list.student_id = $1');
        values.push(searchId);
    }

    // ถ้ามีการค้นหาวันที่
    if (searchDate && searchDate.trim() !== '') {
        conditions.push(`DATE(student_list.active_date) = $${values.length + 1}`);
        values.push(searchDate);
    }

    // รวมเงื่อนไขการค้นหา
    if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
    }

    query += ' ORDER BY student_list.active_date DESC';

    try {
        const result = await pool.query(query, values);
        res.render('student_list', {
            attendanceRecords: result.rows,
            errorMessage: null 
        });
    } catch (error) {
        console.error(error);
        res.render('student_list', {
            attendanceRecords: [],
            errorMessage: 'เกิดข้อผิดพลาดในการดึงข้อมูล'
        });
    }
});




// เริ่มต้นเซิร์ฟเวอร์
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
